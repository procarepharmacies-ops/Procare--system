"""
tools/db_reader.py
──────────────────
READ-ONLY connection to ProCare Stock SQL Server database.
NEVER writes, updates, or deletes anything.
All data flows OUT only: ProCare Stock → PharmacyOS dashboard.

Usage:
    python db_reader.py               # runs all diagnostics
    python db_reader.py --test        # connection test only
"""

import os
import sys
import json
import pyodbc
import pandas as pd
from datetime import datetime, date
from dotenv import load_dotenv

load_dotenv()

# ─── CONNECTION ───────────────────────────────────────────────────────────────

def get_connection():
    """
    Build READ-ONLY connection to ProCare Stock SQL Server.
    Credentials from .env file — never hardcoded.
    """
    server   = os.getenv("PROCARE_SERVER",   "localhost")
    database = os.getenv("PROCARE_DATABASE", "stock")
    username = os.getenv("PROCARE_USER",     "sa")
    password = os.getenv("PROCARE_PASSWORD", "")

    conn_str = (
        f"DRIVER={{ODBC Driver 17 for SQL Server}};"
        f"SERVER={server};"
        f"DATABASE={database};"
        f"UID={username};"
        f"PWD={password};"
        "ApplicationIntent=ReadOnly;"   # READ-ONLY flag
        "Encrypt=no;"
        "TrustServerCertificate=yes;"
        "ConnectTimeout=10;"
    )
    try:
        conn = pyodbc.connect(conn_str)
        return conn
    except pyodbc.Error as e:
        # Try Windows Authentication as fallback
        conn_str_win = (
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={server};"
            f"DATABASE={database};"
            "Trusted_Connection=yes;"
            "ApplicationIntent=ReadOnly;"
            "ConnectTimeout=10;"
        )
        return pyodbc.connect(conn_str_win)


def test_connection():
    """Quick connection test — returns True/False + version string."""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT @@VERSION, DB_NAME()")
        row = cursor.fetchone()
        conn.close()
        print(f"✅ Connected: {row[1]}")
        print(f"   SQL Server: {row[0][:60]}...")
        return True
    except Exception as e:
        print(f"❌ Connection failed: {e}")
        return False


# ─── CORE READERS ─────────────────────────────────────────────────────────────

def read_table(table_name: str, limit: int = None) -> pd.DataFrame:
    """Generic READ-ONLY table reader."""
    conn = get_connection()
    query = f"SELECT TOP {limit} * FROM {table_name}" if limit else f"SELECT * FROM {table_name}"
    df = pd.read_sql(query, conn)
    conn.close()
    return df


def run_query(sql: str) -> pd.DataFrame:
    """Run any SELECT query. Blocks non-SELECT statements."""
    sql_clean = sql.strip().upper()
    forbidden = ["INSERT", "UPDATE", "DELETE", "DROP", "TRUNCATE", "ALTER", "CREATE", "EXEC"]
    for word in forbidden:
        if sql_clean.startswith(word):
            raise PermissionError(f"❌ BLOCKED: '{word}' not allowed. READ-ONLY mode.")
    conn = get_connection()
    df = pd.read_sql(sql, conn)
    conn.close()
    return df


# ─── DIAGNOSTIC QUERIES ───────────────────────────────────────────────────────

def get_row_counts() -> pd.DataFrame:
    """Row counts for all major tables — shows how much real data exists."""
    sql = """
    SELECT 'Products'        AS table_name, COUNT(*) AS row_count FROM Products        UNION ALL
    SELECT 'Sales_header',                  COUNT(*)             FROM Sales_header      UNION ALL
    SELECT 'Sales_details',                 COUNT(*)             FROM Sales_details     UNION ALL
    SELECT 'Purchase_header',               COUNT(*)             FROM Purchase_header   UNION ALL
    SELECT 'Purchase_details',              COUNT(*)             FROM Purchase_details  UNION ALL
    SELECT 'Customer',                      COUNT(*)             FROM Customer          UNION ALL
    SELECT 'Vendor',                        COUNT(*)             FROM Vendor            UNION ALL
    SELECT 'Employee',                      COUNT(*)             FROM Employee          UNION ALL
    SELECT 'Branches',                      COUNT(*)             FROM Branches          UNION ALL
    SELECT 'Account_Tree',                  COUNT(*)             FROM Account_Tree      UNION ALL
    SELECT 'Stores',                        COUNT(*)             FROM Stores            UNION ALL
    SELECT 'Product_groups',                COUNT(*)             FROM Product_groups
    ORDER BY row_count DESC
    """
    return run_query(sql)


def get_branches() -> pd.DataFrame:
    """All branches — confirms Mashala + Elsanta."""
    return run_query("SELECT * FROM Branches")


def get_company_info() -> pd.DataFrame:
    """Company settings from co_inf table."""
    return run_query("SELECT * FROM co_inf")


def get_sales_date_range() -> dict:
    """Oldest and newest sale — shows years of history."""
    try:
        df = run_query("""
            SELECT
                MIN(Date_time)  AS oldest_sale,
                MAX(Date_time)  AS newest_sale,
                COUNT(*)        AS total_invoices,
                COUNT(DISTINCT CAST(Date_time AS DATE)) AS trading_days
            FROM Sales_header
        """)
        row = df.iloc[0]
        return {
            "oldest":         str(row["oldest_sale"]),
            "newest":         str(row["newest_sale"]),
            "total_invoices": int(row["total_invoices"]),
            "trading_days":   int(row["trading_days"]),
        }
    except Exception as e:
        return {"error": str(e)}


def check_password_security() -> dict:
    """
    Checks how passwords are stored — CRITICAL security check.
    Does NOT expose actual passwords — only checks storage format.
    """
    try:
        df = run_query("SELECT TOP 3 LEN(password) AS pwd_len, password AS pwd_sample FROM user_login")
        samples = df["pwd_sample"].tolist()
        lengths = df["pwd_len"].tolist()

        # Analyze format
        if all(len(str(s)) < 20 for s in samples):
            security = "🔴 CRITICAL — Likely PLAIN TEXT"
            action   = "Change all passwords immediately"
        elif all(len(str(s)) == 32 for s in samples):
            security = "🟠 HIGH RISK — MD5 hash (crackable)"
            action   = "Upgrade to bcrypt hashing"
        elif all(len(str(s)) == 64 for s in samples):
            security = "🟡 MEDIUM — SHA-256 (better but not ideal)"
            action   = "Consider upgrading to bcrypt"
        elif all(len(str(s)) > 50 for s in samples):
            security = "🟢 GOOD — Likely bcrypt/modern hash"
            action   = "No action needed"
        else:
            security = "⚪ UNKNOWN — Manual check needed"
            action   = "Inspect user_login table manually"

        return {
            "security_level": security,
            "action_required": action,
            "sample_lengths": lengths,
        }
    except Exception as e:
        return {"error": str(e)}


# ─── BUSINESS INTELLIGENCE READERS ───────────────────────────────────────────

def get_daily_sales(branch_id=None, target_date=None) -> pd.DataFrame:
    """Today's sales summary by branch."""
    date_str = target_date or date.today().strftime("%Y-%m-%d")
    branch_filter = f"AND sh.Branch_id = {branch_id}" if branch_id else ""
    sql = f"""
    SELECT
        b.Branch_name                   AS branch,
        COUNT(sh.Bill_id)               AS invoices,
        SUM(sh.Total)                   AS gross_sales,
        SUM(sh.Discount)                AS total_discount,
        SUM(sh.Net)                     AS net_sales,
        SUM(sh.Tax)                     AS tax,
        AVG(sh.Net)                     AS avg_invoice
    FROM Sales_header sh
    JOIN Branches b ON sh.Branch_id = b.Branch_id
    WHERE CAST(sh.Date_time AS DATE) = '{date_str}'
      AND sh.Is_deleted = 0
      {branch_filter}
    GROUP BY b.Branch_id, b.Branch_name
    ORDER BY net_sales DESC
    """
    return run_query(sql)


def get_top_products(limit=20, days=30) -> pd.DataFrame:
    """Top selling products by quantity and revenue in the last N days."""
    sql = f"""
    SELECT TOP {limit}
        p.Product_name                  AS product,
        pg.Group_name                   AS category,
        SUM(sd.Qty)                     AS qty_sold,
        SUM(sd.Total)                   AS revenue,
        AVG(sd.Price)                   AS avg_price
    FROM Sales_details sd
    JOIN Sales_header sh  ON sd.Bill_id      = sh.Bill_id
    JOIN Products p       ON sd.Product_id   = p.Product_id
    LEFT JOIN Product_groups pg ON p.Group_id = pg.Group_id
    WHERE sh.Date_time >= DATEADD(day, -{days}, GETDATE())
      AND sh.Is_deleted = 0
    GROUP BY p.Product_id, p.Product_name, pg.Group_name
    ORDER BY qty_sold DESC
    """
    return run_query(sql)


def get_low_stock(threshold_override=None) -> pd.DataFrame:
    """Products at or below reorder level — needs restocking."""
    sql = """
    SELECT
        p.Product_name                  AS product,
        p.Product_code                  AS code,
        p.Barcode                       AS barcode,
        pa.Amount                       AS current_stock,
        p.Min_amount                    AS reorder_level,
        (p.Min_amount - pa.Amount)      AS deficit,
        v.Vendor_name                   AS supplier,
        b.Branch_name                   AS branch
    FROM Products p
    JOIN Product_Amount pa  ON p.Product_id  = pa.Product_id
    JOIN Branches b         ON pa.Store_id   = b.Branch_id
    LEFT JOIN Vendor v      ON p.Vendor_id   = v.Vendor_id
    WHERE pa.Amount <= p.Min_amount
      AND p.Is_deleted = 0
      AND pa.Amount >= 0
    ORDER BY deficit DESC
    """
    return run_query(sql)


def get_expiry_alerts(days_ahead=90) -> pd.DataFrame:
    """Products expiring within N days — pharmacy compliance critical."""
    sql = f"""
    SELECT
        p.Product_name                          AS product,
        p.Product_code                          AS code,
        pa.Amount                               AS stock_qty,
        pa.Expiry_date                          AS expiry_date,
        DATEDIFF(day, GETDATE(), pa.Expiry_date) AS days_remaining,
        b.Branch_name                           AS branch,
        CASE
            WHEN pa.Expiry_date < GETDATE()
                THEN '🔴 EXPIRED'
            WHEN DATEDIFF(day, GETDATE(), pa.Expiry_date) <= 30
                THEN '🟠 CRITICAL (≤30 days)'
            WHEN DATEDIFF(day, GETDATE(), pa.Expiry_date) <= 90
                THEN '🟡 WARNING (≤90 days)'
        END AS alert_level
    FROM Products p
    JOIN Product_Amount pa ON p.Product_id = pa.Product_id
    JOIN Branches b        ON pa.Store_id  = b.Branch_id
    WHERE pa.Expiry_date <= DATEADD(day, {days_ahead}, GETDATE())
      AND pa.Amount > 0
      AND p.Is_deleted = 0
    ORDER BY pa.Expiry_date ASC
    """
    return run_query(sql)


def get_branch_comparison(days=30) -> pd.DataFrame:
    """Side-by-side performance: Mashala vs Elsanta."""
    sql = f"""
    SELECT
        b.Branch_name                   AS branch,
        COUNT(sh.Bill_id)               AS total_invoices,
        SUM(sh.Net)                     AS total_revenue,
        AVG(sh.Net)                     AS avg_invoice_value,
        MAX(sh.Net)                     AS largest_invoice,
        COUNT(DISTINCT sh.Customer_id)  AS unique_customers
    FROM Sales_header sh
    JOIN Branches b ON sh.Branch_id = b.Branch_id
    WHERE sh.Date_time >= DATEADD(day, -{days}, GETDATE())
      AND sh.Is_deleted = 0
    GROUP BY b.Branch_id, b.Branch_name
    ORDER BY total_revenue DESC
    """
    return run_query(sql)


def get_supplier_performance(days=90) -> pd.DataFrame:
    """Supplier purchase summary — who we buy most from."""
    sql = f"""
    SELECT TOP 20
        v.Vendor_name                   AS supplier,
        COUNT(ph.Purchase_id)           AS orders,
        SUM(ph.Total)                   AS total_purchased,
        AVG(ph.Total)                   AS avg_order_value,
        MAX(ph.Date_time)               AS last_order
    FROM Purchase_header ph
    JOIN Vendor v ON ph.Vendor_id = v.Vendor_id
    WHERE ph.Date_time >= DATEADD(day, -{days}, GETDATE())
      AND ph.Is_deleted = 0
    GROUP BY v.Vendor_id, v.Vendor_name
    ORDER BY total_purchased DESC
    """
    return run_query(sql)


def get_monthly_trend(months=12) -> pd.DataFrame:
    """Monthly revenue trend — last N months across all branches."""
    sql = f"""
    SELECT
        FORMAT(sh.Date_time, 'yyyy-MM')     AS month,
        b.Branch_name                       AS branch,
        COUNT(sh.Bill_id)                   AS invoices,
        SUM(sh.Net)                         AS revenue
    FROM Sales_header sh
    JOIN Branches b ON sh.Branch_id = b.Branch_id
    WHERE sh.Date_time >= DATEADD(month, -{months}, GETDATE())
      AND sh.Is_deleted = 0
    GROUP BY FORMAT(sh.Date_time, 'yyyy-MM'), b.Branch_id, b.Branch_name
    ORDER BY month ASC, revenue DESC
    """
    return run_query(sql)


# ─── FULL DIAGNOSTIC REPORT ───────────────────────────────────────────────────

def run_full_diagnostic():
    """Run all diagnostics and save to .tmp/diagnostic_results.json"""
    print("\n" + "="*60)
    print("  ProCare Pharmacy — Full Diagnostic")
    print("="*60)

    results = {}

    print("\n[1/6] Testing connection...")
    results["connection"] = test_connection()

    print("\n[2/6] Row counts...")
    try:
        df = get_row_counts()
        results["row_counts"] = df.to_dict("records")
        print(df.to_string(index=False))
    except Exception as e:
        results["row_counts"] = {"error": str(e)}
        print(f"  ❌ {e}")

    print("\n[3/6] Branches...")
    try:
        df = get_branches()
        results["branches"] = df.to_dict("records")
        print(df.to_string(index=False))
    except Exception as e:
        results["branches"] = {"error": str(e)}

    print("\n[4/6] Sales date range...")
    try:
        r = get_sales_date_range()
        results["sales_range"] = r
        print(f"  Oldest: {r.get('oldest')} | Newest: {r.get('newest')}")
        print(f"  Total invoices: {r.get('total_invoices'):,}")
    except Exception as e:
        results["sales_range"] = {"error": str(e)}

    print("\n[5/6] Password security check...")
    try:
        r = check_password_security()
        results["password_security"] = r
        print(f"  {r.get('security_level')}")
        print(f"  Action: {r.get('action_required')}")
    except Exception as e:
        results["password_security"] = {"error": str(e)}

    print("\n[6/6] Company info...")
    try:
        df = get_company_info()
        results["company"] = df.to_dict("records")
        print(df.to_string(index=False))
    except Exception as e:
        results["company"] = {"error": str(e)}

    # Save results
    os.makedirs(".tmp", exist_ok=True)
    out_path = ".tmp/diagnostic_results.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2, default=str)

    print(f"\n✅ Full diagnostic saved to: {out_path}")
    print("="*60 + "\n")
    return results


# ─── MAIN ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if "--test" in sys.argv:
        test_connection()
    else:
        run_full_diagnostic()
