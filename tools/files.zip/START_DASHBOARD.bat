@echo off
title ProCare Pharmacy Dashboard
color 0A
echo.
echo  ===================================
echo    ProCare Pharmacy Dashboard
echo    Starting all services...
echo  ===================================
echo.

:: Check Python
python --version > nul 2>&1
if errorlevel 1 (
    echo  ERROR: Python not found. Please install Python 3.10+
    pause
    exit
)

:: Install dependencies if needed
echo  [1/3] Checking dependencies...
pip install -r requirements.txt -q

:: Copy .env if missing
if not exist .env (
    echo  [2/3] Setting up .env from template...
    copy .env.template .env
    echo.
    echo  IMPORTANT: Edit .env file and add your SQL Server password!
    echo  File location: %CD%\.env
    notepad .env
    pause
) else (
    echo  [2/3] .env found OK
)

:: Start API server in background
echo  [3/3] Starting API server...
cd tools
start "ProCare API" /min python api_server.py

:: Wait a moment for server to start
timeout /t 2 /nobreak > nul

:: Open dashboard in browser
echo.
echo  Opening dashboard in browser...
start http://localhost:5000
start dashboard.html

echo.
echo  Dashboard is running!
echo  Press any key to stop the server.
pause > nul

:: Kill the API server when user presses a key
taskkill /f /im python.exe /fi "WINDOWTITLE eq ProCare API" > nul 2>&1
echo  Server stopped. Goodbye!
