"""
tools/api_server.py
────────────────────
Flask API — serves ProCare Stock data to the dashboard.
READ-ONLY. Runs on localhost:5000.
Start with: python api_server.py
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
from db_reader import (
    get_daily_sales, get_top_products, get_low_stock,
    get_expiry_alerts, get_branch_comparison,
    get_supplier_performance, get_monthly_trend,
    get_branches, get_company_info, test_connection
)
from datetime import date
import traceback

app = Flask(__name__)
CORS(app)  # Allow dashboard to connect


def api_response(data=None, error=None, status=200):
    if error:
        return jsonify({"ok": False, "error": str(error)}), 500
    return jsonify({"ok": True, "data": data, "timestamp": str(date.today())}), status


# ─── HEALTH ───────────────────────────────────────────────────────────────────

@app.route("/api/health")
def health():
    ok = test_connection()
    return api_response({"connected": ok, "database": "stock", "pharmacy": "ProCare"})


# ─── DASHBOARD ENDPOINTS ──────────────────────────────────────────────────────

@app.route("/api/sales/today")
def sales_today():
    try:
        df = get_daily_sales()
        return api_response(df.to_dict("records"))
    except Exception as e:
        return api_response(error=e)


@app.route("/api/sales/monthly")
def sales_monthly():
    try:
        months = int(request.args.get("months", 12))
        df = get_monthly_trend(months)
        return api_response(df.to_dict("records"))
    except Exception as e:
        return api_response(error=e)


@app.route("/api/branches/comparison")
def branches():
    try:
        days = int(request.args.get("days", 30))
        df = get_branch_comparison(days)
        return api_response(df.to_dict("records"))
    except Exception as e:
        return api_response(error=e)


@app.route("/api/products/top")
def top_products():
    try:
        limit = int(request.args.get("limit", 20))
        days  = int(request.args.get("days", 30))
        df = get_top_products(limit, days)
        return api_response(df.to_dict("records"))
    except Exception as e:
        return api_response(error=e)


@app.route("/api/inventory/low-stock")
def low_stock():
    try:
        df = get_low_stock()
        return api_response(df.to_dict("records"))
    except Exception as e:
        return api_response(error=e)


@app.route("/api/inventory/expiry")
def expiry_alerts():
    try:
        days = int(request.args.get("days", 90))
        df = get_expiry_alerts(days)
        return api_response(df.to_dict("records"))
    except Exception as e:
        return api_response(error=e)


@app.route("/api/suppliers")
def suppliers():
    try:
        days = int(request.args.get("days", 90))
        df = get_supplier_performance(days)
        return api_response(df.to_dict("records"))
    except Exception as e:
        return api_response(error=e)


@app.route("/api/company")
def company():
    try:
        df = get_company_info()
        return api_response(df.to_dict("records"))
    except Exception as e:
        return api_response(error=e)


# ─── MAIN ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("\n🏥 ProCare Pharmacy API Server")
    print("   READ-ONLY connection to ProCare Stock")
    print("   Dashboard: http://localhost:5000\n")
    app.run(host="0.0.0.0", port=5000, debug=False)
